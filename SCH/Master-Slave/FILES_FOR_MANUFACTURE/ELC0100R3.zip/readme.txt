Eli hughes
Playworld System
1000 Buffalo Rd
Lewisburg, PA 17837
5705229800


ELC0100R3


ELC100R3.GBL   Bottom Layer
ELC100R3.GBo   Bottom Silkscreen
ELC100R3.GBS   Bottom Soldermask
ELC100R3.GM3   Board Cutouts
ELC100R3.GM1   Board Outline
ELC100R3.GP1   Inner Ground Plane - Negative Image
ELC100R3.GP2   Inner Power Plane - Negative Image
ELC100R3.GTS   Top Soldermask
ELC100R3.GTO   Top Silkscreen
ELC100R3.DRL   NC Drill File


4-Layer PCB - 1OZ copper.   Inner Copper are Negative images

Layer Stackup:

Top  	     ELC100R3.GTL
Inner Ground ELC100R3.GP1   Negative Image
Inner power  ELC100R3.GP2   Negative Image
Bottom	     ELC100R3.GBL

