Eli hughes
Playworld System
1000 Buffalo Rd
Lewisburg, PA 17837
5705229800


ELC0100R4


ELC100R4.GBL   Bottom Layer
ELC100R4.GBo   Bottom Silkscreen
ELC100R4.GBS   Bottom Soldermask
ELC100R4.GM3   Board Cutouts
ELC100R4.GM1   Board Outline
ELC100R4.GP1   Inner Ground Plane - Negative Image
ELC100R4.GP2   Inner Power Plane - Negative Image
ELC100R4.GTS   Top Soldermask
ELC100R4.GTO   Top Silkscreen
ELC100R4.DRL   NC Drill File


4-Layer PCB - 1OZ copper.   Inner Copper are Negative images

Layer Stackup:

Top  	     ELC100R4.GTL
Inner Ground ELC100R4.GP1   Negative Image
Inner power  ELC100R4.GP2   Negative Image
Bottom	     ELC100R4.GBL

